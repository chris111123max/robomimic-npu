"""V5 control-plane validator; deliberately contains no V4 10K gate checks."""
import argparse, json
from pathlib import Path
from stage3_v5_schedule import CriticHandoff, TrainingState

def main():
 p=argparse.ArgumentParser(); p.add_argument("--config",default=str(Path(__file__).with_name("stage3_v5_config.json"))); a=p.parse_args()
 c=json.loads(Path(a.config).read_text()); h=CriticHandoff(c)
 assert h.state.state == TrainingState.CRITIC_ONLY
 assert not h.readiness_due(99999)
 def m(step, ok=True): return {"env_steps":step,"completed_episodes":150,"success_episodes":30,"failure_episodes":30,"spearman_q_return":.7,"success_failure_auc":.8,"delta_q":.1,"twin_q_disagreement_median":.1,"twin_q_disagreement_p95":.25,"td_plateau":ok,"td_error_worsening":False,"q_scale_stable":True,"ood_stress_pass":True,"finite":True}
 h.submit_readiness(m(100000)); h.submit_readiness(m(110000)); h.submit_readiness(m(120000)); assert h.state.state == TrainingState.ACTOR_WARMUP
 start=h.state.critic_ready_step; end=start+h.state.actor_warmup_steps
 assert h.schedule(start,.0003)["actor_lr"] == 0.0
 assert abs(h.schedule(end,.0003)["actor_lr"]-2e-6)<1e-12
 assert abs(h.schedule(end,.0003)["critic_lr"]-7.5e-5)<1e-12
 assert h.evaluation_due(end); assert not h.evaluation_due(end+1)
 print(json.dumps({"status":"PASS","state":"JOINT_RL","critic_ready_step":start,"actor_warmup_steps":h.state.actor_warmup_steps,"utd":c["utd"],"policy_delay":c["policy_delay"]},indent=2))
if __name__ == "__main__": main()
