#!/usr/bin/env python3
"""Summarize measured Stage3-v5 throughput and collector/learner timing."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

PHASES = ("CRITIC_ONLY", "ACTOR_WARMUP", "JOINT_RL", "CRITIC_NOT_READY")
THROUGHPUT_KEYS = ("aggregate_env_steps_per_sec", "critic_updates_per_sec",
                   "actor_updates_per_sec")
TIMING_KEYS = ("actor_inference_ms", "vector_env_step_ms", "critic_replay_ms",
               "critic_update_ms", "actor_replay_ms", "actor_update_ms",
               "polyak_update_ms", "round_replay_prepare_ms", "round_wall_ms",
               "collector_learner_overlap_ms",
               "round_critic_updates", "round_actor_updates",
               "prefetch_requested_critic_batches",
               "prefetch_prepared_critic_batches",
               "prefetch_prepared_actor_batches")


def _rows(path):
    path = Path(path)
    if not path.is_file():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()]


def _mean(rows, key):
    values = [float(row[key]) for row in rows if key in row]
    return sum(values) / len(values) if values else None


def summarize(path):
    rows = _rows(path)
    if not rows:
        raise RuntimeError(f"No throughput rows in {path}")
    result = {}
    for phase in PHASES:
        selected = [row for row in rows if row.get("phase") == phase]
        result[phase] = {"samples": len(selected),
                         **{key: _mean(selected, key) for key in THROUGHPUT_KEYS}}
    result["all"] = {"samples": len(rows),
                     **{key: _mean(rows, key) for key in THROUGHPUT_KEYS}}
    return result


def summarize_timing(path):
    rows = _rows(path)
    return {"samples": len(rows),
            **{key: _mean(rows, key) for key in TIMING_KEYS}}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pair-run-dir", required=True)
    parser.add_argument("--group", choices=("rnn_q", "multi_q"), required=True)
    parser.add_argument("--v3-throughput-jsonl", help="optional matched baseline log")
    args = parser.parse_args()
    group_dir = Path(args.pair_run_dir) / args.group
    report = {"stage": "stage3-v5", "group": args.group,
              "throughput": summarize(group_dir / "throughput_metrics.jsonl"),
              "stage_timing": summarize_timing(group_dir / "stage_timing.jsonl"),
              "measurement_contract": {
                  "env_steps": "aggregate transitions across 16 environments",
                  "phase_source": "CriticHandoff state, never an env-step threshold",
                  "prefetch": "requested and prepared optimizer batches per sampled round",
              }}
    if args.v3_throughput_jsonl:
        baseline = summarize(args.v3_throughput_jsonl)
        report["baseline"] = baseline
        for phase in PHASES:
            current = report["throughput"][phase]["aggregate_env_steps_per_sec"]
            previous = baseline.get(phase, {}).get("aggregate_env_steps_per_sec")
            report.setdefault("speedup_vs_baseline", {})[phase] = (
                current / previous if current is not None and previous else None)
    output = group_dir / "throughput_benchmark.json"
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(output), **report}, indent=2))


if __name__ == "__main__":
    main()
